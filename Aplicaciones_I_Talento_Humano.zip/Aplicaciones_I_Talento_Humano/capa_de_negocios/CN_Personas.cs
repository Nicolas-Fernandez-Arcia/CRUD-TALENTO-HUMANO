﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using capa_de_datos;

namespace capa_de_negocios
{
    public class CN_Personas
    {
        private CD_postulantes objetoCD = new CD_postulantes();

        //LLAMR LA TABLA POSTULANTES DE LA BASE DE DATOS
        public DataTable MostrarPer()  // metodo que se encarga de hacer conexion especificamente con la tabla personas a la que se le haran consultas
        {
            DataTable tabla = new DataTable();
            tabla = objetoCD.Mostrar();
            return tabla;
        }

        //METODO QUE COMBIERTE LOS VALORES DE TXT A NUMEROS O VALORES NUMERICOS
        public void InsertarPer(string nombres, string apellido, string profesion, string años, string cc)
        {
            objetoCD.Insertar(nombres, apellido, profesion, Convert.ToInt32(años), Convert.ToInt32(cc));
        }

        //METODO QUE IDENTIFICA LA ID DEL DATO A EDITAR
        public void EditarPer(string nombres, string apellido, string profesion, string años, string cc, string id)
        {
            objetoCD.Editar(nombres, apellido, profesion, Convert.ToInt32(años), Convert.ToInt32(cc), Convert.ToInt32(id));
        }

        //METODO QUE IDENTIFICA EL ID DE LOS DATOS A ELIMINAR
        public void EliminarPer(string id)
        {
            objetoCD.Eliminar(Convert.ToInt32(id));
        }
    }
}
