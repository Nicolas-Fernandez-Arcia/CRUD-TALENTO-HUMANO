﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using capa_de_negocios;

namespace capa_de_presentacion
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        //METODO QUE HACE APARECER EL FORM LOGIN DENTRO DEL FORM1
        private void formulario1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            login frm = new login();
            frm.MdiParent = this;
            frm.Show();
        }

        //METODO QUE HACE APARECER EL FORM CRUD DESDE LOS BOTONES DEL FORM1
        private void cRUDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            crud frm = new crud();
            frm.Show();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        //METODO QUE TRANSFORMA EL FORM1 COMO EL FORM PADRE
        private void infoEmperadorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InformacionEmperador  frm = new InformacionEmperador();
            frm.MdiParent = this;
            frm.Show();
        }
    }
}
