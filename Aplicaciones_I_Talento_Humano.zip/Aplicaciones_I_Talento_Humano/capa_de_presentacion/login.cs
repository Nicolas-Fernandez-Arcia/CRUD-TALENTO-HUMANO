﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace capa_de_presentacion
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        //METODO DE VALIDACION DE CAMPO
        private bool ValidarCampo()  
        {
            bool ok = true;
            if (usuario.Text == "")
            {
                ok = false;
                errorProvider1.SetError(usuario, "ingresar usuario");
            }

            if (contraseña.Text == "")
            {
                ok = false;
                errorProvider1.SetError(contraseña, "ingresar contraseña");
            }

            return ok;

            var vr = !string.IsNullOrEmpty(usuario.Text) &&  //ESTAS LINEAS SE ENCARGAN DE HACER QUE SOLO SI TODO ESTA BIEN 
                !string.IsNullOrEmpty(contraseña.Text);      //SE VA A PODER SEGUIR A LA BASE DE DATOS
            button1.Enabled = vr;
        }

        //METODO QUE SE ENCARGA DE QUITAR LOS ERROR CUANDO LOS CAMPOS YA FUERON DILIJENCIADOS
        private void BorrarMensajeError()
        {
            errorProvider1.SetError(usuario, "");  
            errorProvider1.SetError(contraseña, "");
        }

        //LLAMA LA DETECCION DE CAMPO A USUARIO
        private void usuario_TextChanged_1(object sender, EventArgs e)
        {
            ValidarCampo();
        }

        //LLAMA LA DETECCION DE CAMPO A CONTRASEÑA
        private void contraseña_TextChanged(object sender, EventArgs e)
        {
            ValidarCampo();
        }

        //ESTE METOD ME AYUDA A QUE SOL SI ES UN USUARIO DETERMINADO SE PUEDE SEGUIR A LA BASE DE DATOS
        private void usuario_Validating(object sender, CancelEventArgs e)
        {

            if (usuario.Text == "nicolas")
            {

            }
            else
            {
                e.Cancel = true;
                contraseña.Select(0, contraseña.Text.Length);
                MessageBox.Show("usuario incorrecto");
            }
        }

        //ESTE METOD ME AYUDA A QUE SOL SI ES UNA CONTRASEÑA DETERMINADA SE PUEDE SEGUIR A LA BASE DE DATOS
        private void contraseña_Validating(object sender, CancelEventArgs e)
        {

            if (contraseña.Text == "0524")
            {

            }
            else
            {
                e.Cancel = true;
                contraseña.Select(0, contraseña.Text.Length);
                MessageBox.Show("contraseña incorrecto");
            }
        }

        //SOLO SI TOD LO ANTERIOR ESTA BIEN EL BOTON TE DEJARA AVANZAR
        private void button1_Click(object sender, EventArgs e)
        {
            BorrarMensajeError();
            if (ValidarCampo())
            {
                MessageBox.Show("Login correcto");
            }
            crud frm = new crud();
            frm.Show();
        }


        //METODO PARA HACER QUE LOS LABEL <HORA> Y <FECHA> MUESTRES ESTOS MISMOS DATOS
        private void HoraFecha_Tick(object sender, EventArgs e)
        {
            hora.Text = DateTime.Now.ToShortTimeString();
            fecha.Text = DateTime.Now.ToShortDateString();
        }

        private void fecha_Click(object sender, EventArgs e)
        {

        }
    }
}
