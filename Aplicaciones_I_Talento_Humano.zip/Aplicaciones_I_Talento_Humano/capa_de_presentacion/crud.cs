﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using capa_de_negocios;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Diagnostics;
using System.IO;

namespace capa_de_presentacion
{
    public partial class crud : Form
    {
        CN_Personas objetoCN = new CN_Personas();  // Llamar el CD_personas para crear la conexion
        private string idPersona = null;  // Linea que se encarga de el id ya que es autoincrementable
        private bool Editar = false;  // Se encarga de que editar sea nulo para que el if se encarge de su activacion y ejecucion

        public crud()
        {
            InitializeComponent();
        }

        //LLAMAR EL METODO MOSTRAR AL CRUD
        private void crud_Load(object sender, EventArgs e)
        {
            MostrarPersonas();  //Aqui se vincula la base de datos al Form que se encarga de la base de datos
        }

        //METODO QUE MUESTRA LA BASE DE DATOS
        private void MostrarPersonas()
        {
            CN_Personas objeto = new CN_Personas();
            DataGridView.DataSource = objeto.MostrarPer();  //Aqui se mensiona al Grid para que en el se vea la tabla de la base de datos
        }

        //BOTON QUE INSERTA EN LA BASE DE DATOS
        private void button2_Click(object sender, EventArgs e)
        {

            //INSERTAR
            if (Editar == false)  
            {
                try  // Capturar errores, Si la isercion fue correcta o no
                {
                    objetoCN.InsertarPer(txtNombre.Text, txtApellido.Text, txtProfesion.Text, txtExperiencia.Text, txtCC.Text);
                    MessageBox.Show("Se inserto correctamente");  //mensaje de insercion correcta
                    MostrarPersonas();
                    limpiarForm();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("No se pudo insertar los datos por: " + ex); //mensaje de insercion incorrecta mas error
                }
            }

            //EDITAR
            if (Editar == true)
            {
                try
                {
                    objetoCN.EditarPer(txtNombre.Text, txtApellido.Text, txtProfesion.Text, txtExperiencia.Text, txtCC.Text, idPersona);
                    MessageBox.Show("Se edito correctamente");  //mensaje de edicion correcta
                    MostrarPersonas();
                    limpiarForm();
                    Editar = false;  //reiniciar parametro Editar, para evitar errores y que sea mas fluido
                }
                catch(Exception ex)
                {
                    MessageBox.Show("No se pudo editar los datos por: " + ex); //mensaje de insercion incorrecta mas error
                }
            }
        }

        //BOTON QUE EDITA EN LA BASE DE DATOS
        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (DataGridView.SelectedRows.Count > 0)  //las columnas que seran modificadas 
            {
                Editar = true;
                txtNombre.Text = DataGridView.CurrentRow.Cells["Nombres"].Value.ToString();
                txtApellido.Text = DataGridView.CurrentRow.Cells["Apellidos"].Value.ToString();
                txtProfesion.Text = DataGridView.CurrentRow.Cells["Profesion"].Value.ToString();
                txtExperiencia.Text = DataGridView.CurrentRow.Cells["Años_Experiencia"].Value.ToString();
                txtCC.Text = DataGridView.CurrentRow.Cells["CC"].Value.ToString();
                idPersona = DataGridView.CurrentRow.Cells["ID"].Value.ToString();
            }
            else
                MessageBox.Show("selecciones una fila porfavor"); //mensaje de aviso (no se a seleccionado una fila)
        }

        //METODO PARA LIMPIAR CASILLAS LUEGO DE MODIFICAR
        private void limpiarForm()
        {
            txtNombre.Clear();
            txtApellido.Clear();
            txtProfesion.Clear();
            txtExperiencia.Clear();
            txtCC.Clear();
        }

        //METOD PARA IDENTIFICAR SI EL DELETE A SIDO EXITOSO O NO SE HA SELECCIONADO UNA FILA
        private void button3_Click(object sender, EventArgs e)
        {
            if (DataGridView.SelectedRows.Count > 0)
            {
                idPersona = DataGridView.CurrentRow.Cells["id"].Value.ToString();
                objetoCN.EliminarPer(idPersona);
                MessageBox.Show("Eliminado correctamente");
                MostrarPersonas();
            }
            else
                MessageBox.Show("selecciones una fila porfavor");
        }

        //METOD PARA EXPORTAR A EXCEL LA BASE DE DATOS
        public void ExportarDatos(DataGridView datalistado)
        {
            Microsoft.Office.Interop.Excel.Application exportaexcel = new Microsoft.Office.Interop.Excel.Application();

            exportaexcel.Application.Workbooks.Add(true);  //Crear nuevo libro y que sea visible

            int indicecolumna = 0;

            foreach (DataGridViewColumn columna in datalistado.Columns)
            {
                indicecolumna++;  //Aumentar columnas 1 a 1

                exportaexcel.Cells[1, indicecolumna] = columna.Name; //Leer nombre de todas las columnas
            }

            int indicefila = 0; foreach (DataGridViewRow fila in datalistado.Rows)
            {
                indicefila++;  //Aumenta filas 1 a 1
                indicecolumna = 0;  //Comenzar desde cero

                foreach (DataGridViewColumn columna in datalistado.Columns)  //Aqui estba el error y era luego del datalistado decia columna no columns
                {
                    indicecolumna++;  //Aumentar columnas 1 a 1

                    exportaexcel.Cells[indicefila + 1, indicecolumna] = fila.Cells[columna.Name].Value;  // repetir proceso anterior
                }
            }
            exportaexcel.Visible = true;  //ver ewcel con los datos
        }

        //EL DATAGRIDVIEW
        private void DataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //BOTON QUE EJECUTA EL METODO DE EXPORTACION A EXCEL
        private void button4_Click_1(object sender, EventArgs e)
        {
            ExportarDatos(DataGridView);
        }
        
        //BOTON QUE EJECUTA LA EXPORTACION A PDF
        private void button5_Click(object sender, EventArgs e)
        {
            if (DataGridView.Rows.Count > 0)
            {
                //GUARDAR EN UN ARCHIVO PDF 
                SaveFileDialog save = new SaveFileDialog();
                save.Filter = "PDF (*.pdf)|*.pdf";
                save.FileName = "Emperador.PDF";
                bool ErrorMessage = false;
                if (save.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(save.FileName))
                    {
                        try
                        {
                            File.Delete(save.FileName);
                        }
                        catch (Exception ex)
                        {
                            //ERROR POR SI NO SE HA PODIDO GUARDAR EL ARCHIVO
                            ErrorMessage = true;
                            MessageBox.Show("no se puede escribir datos en el disco" + ex.Message);
                        }
                    }

                    if (!ErrorMessage)
                    {
                        try
                        {
                            //Diseño de la tabla dentro del pdf
                            PdfPTable pTable = new PdfPTable(DataGridView.Columns.Count);
                            
                            pTable.DefaultCell.Padding = 2;
                            
                            pTable.WidthPercentage = 100;
                            
                            pTable.HorizontalAlignment = Element.ALIGN_LEFT;
                            
                            //Mostrar los nombres de las columnas 
                            foreach (DataGridViewColumn col in DataGridView.Columns)
                            {
                                PdfPCell pCell = new PdfPCell(new Phrase(col.HeaderText));
                                
                                pTable.AddCell(pCell);
                            }
                            
                            //Mostrar las celdas en el pdf
                            foreach (DataGridViewRow viewRow in DataGridView.Rows)
                            {
                                foreach (DataGridViewCell dcell in viewRow.Cells)
                                {
                                    pTable.AddCell(dcell.Value.ToString());
                                }
                            }
                            
                            //Algoritmo para comprovar si la exportacion fue exitosa
                            using (FileStream fileStream = new FileStream(save.FileName, FileMode.Create)) 
                            {
                                
                                Document document = new Document(PageSize.A4, 8f, 16f, 16f, 8f);
                                
                                PdfWriter.GetInstance(document, fileStream);
                                
                                document.Open();
                                
                                document.Add(pTable);
                                
                                document.Close();
                                
                                fileStream.Close();
                            }
                            MessageBox.Show("Datos Exportados Con Exito", "info");
                        }
                        catch (Exception ex)
                        {
                            //Mensaje que se muestra si ha ocurrido algun error en la ejecucion
                            MessageBox.Show("Error al exportar datos" + ex.Message);
                        }
                    }
                }
            }
            else
            {
                //Si ningun dato ha sido encontrado, se muestra mensaje e info
                MessageBox.Show("Ningun dato encontrado", "Info");
            }
        }

        

        
    }
}
