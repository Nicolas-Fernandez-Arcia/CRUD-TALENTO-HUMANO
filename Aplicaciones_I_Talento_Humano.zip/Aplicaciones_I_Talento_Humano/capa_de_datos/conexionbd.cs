﻿ using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace capa_de_datos
{
    public class conexionbd
    {
        private SqlConnection Conexion = new SqlConnection("Server=DESKTOP-2MU7OR3;DataBase= TalentoHumano ; Integrated Security=true");   // crear vinculo con la base de datos

        public SqlConnection AbrirConexion()     // metodo para abri la conexion anteriormente creada
        {
            if (Conexion.State == ConnectionState.Closed)  //Detecta si la base de datos esta cerrada, abrir conexion
                Conexion.Open();
            return Conexion;
        }

        public SqlConnection CerrarConexion()    // metodo para cerrar conexion con base de datos
        {
            if (Conexion.State == ConnectionState.Open)  //Detecta si la base de datos esta abierta, cierra conexion
                Conexion.Close();
            return Conexion;
        }
    }
}
