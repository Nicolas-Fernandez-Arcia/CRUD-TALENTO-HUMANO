﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace capa_de_datos
{
    public class CD_postulantes
    {
        private conexionbd conexion = new conexionbd();

        SqlDataReader leer;  //Lee la base de datos vinculada
        DataTable tabla = new DataTable();  //Lee especificamente la tabla que se quiere usar
        SqlCommand comando = new SqlCommand();   //CREAR OBJETOS QUE AYUDEN A LA LOGICA DEL PROGRAMA

        //METODO PARA MOSTAR LA BASE DE DATOS
        public DataTable Mostrar(){   // crear la consulta para mostrar los datos de la base de datos
        
            comando.Connection = conexion.AbrirConexion();
            comando.CommandText = "MostrarPersonas";
            comando.CommandType = CommandType.StoredProcedure;
            leer = comando.ExecuteReader();
            tabla.Load(leer);
            conexion.CerrarConexion();
            return tabla;
            
        }

        //METODO PARA INSERTAR EN LA BASE DE DATOS
        public void Insertar (string nombres, string apellido, string profesion, int años, int cc) {

            comando.Connection = conexion.AbrirConexion();
            comando.CommandText = "InsetarPersonas";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@Nombres", nombres);
            comando.Parameters.AddWithValue("@Apellidos", apellido);
            comando.Parameters.AddWithValue("@Profesion", profesion);
            comando.Parameters.AddWithValue("@Años_Experiencia", años);
            comando.Parameters.AddWithValue("@CC", cc);

            comando.ExecuteNonQuery();

            comando.Parameters.Clear();
            conexion.CerrarConexion();
        }

        //METODO PARA EDITAR EN LA BASE DE DATOS Y CONSEGUIR LA ID DE LA FILA A EDITAR
        public void Editar(string nombres, string apellido, string profesion, int años, int cc, int id){

            comando.Connection = conexion.AbrirConexion();
            comando.CommandText = "EditarPersonas";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@Nombres", nombres);
            comando.Parameters.AddWithValue("@Apellidos", apellido);
            comando.Parameters.AddWithValue("@Profesion", profesion);
            comando.Parameters.AddWithValue("@Años_Experiencia", años);
            comando.Parameters.AddWithValue("@CC", cc);
            comando.Parameters.AddWithValue("@id", id);

            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //METOD PARA ELIMINAR REGISTROS
        public void Eliminar (int id)
        {
            comando.Connection = conexion.AbrirConexion();
            comando.CommandText = "EliminarPostulante";
            comando.CommandType = CommandType.StoredProcedure;

            comando.Parameters.AddWithValue("@idpro", id);

            comando.ExecuteNonQuery();

            comando.Parameters.Clear();
        }
    }
}
